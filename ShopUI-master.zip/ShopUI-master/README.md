# ShopUI
ShopUI is the first public, functioning ShopUI plugin, by QuiverlyRivalry, and @dapigguy (configuration)

This is my first UI, plugin, I hope you enjoy it!

### Requirements
This plugin requires EconomyAPI & FormsAPI.

### Credits
Special thanks to ArmTheDev for making a tutorial on this!
